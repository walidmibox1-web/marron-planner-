# Maroon Tasks (APK-ready Flutter app)

A minimalist, professional daily tasks app with a white & dark maroon palette and thoughtful features: projects, tags, priority, due dates, reminders, swipe actions, and offline-first storage.

## Quick start

1) Install Flutter (3.22+ recommended) and Android Studio/SDK.
2) Create a new project, then replace files with this repository **OR** just build directly:

```bash
cd maroon_tasks
flutter pub get
flutter run
```

### Build a release APK
```bash
flutter build apk --release
# The APK will be at build/app/outputs/flutter-apk/app-release.apk
```

## Features
- Light/Dark themes (white / dark maroon)
- Create, edit, complete tasks
- Projects & tags
- Due dates and local reminders (Android)
- Priority (Low/Normal/High)
- Search & sort
- Swipe: complete / delete
- Backup/restore (JSON)

