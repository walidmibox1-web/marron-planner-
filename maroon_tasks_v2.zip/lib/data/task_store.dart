import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../models/task.dart';

class Settings {
  final bool darkMode;
  final bool confirmDeletion;
  Settings({required this.darkMode, required this.confirmDeletion});

  Settings copyWith({bool? darkMode, bool? confirmDeletion}) =>
      Settings(darkMode: darkMode ?? this.darkMode, confirmDeletion: confirmDeletion ?? this.confirmDeletion);
}

class TaskStore {
  static final TaskStore instance = TaskStore._();
  TaskStore._();

  final _settings = ValueNotifier<Settings>(Settings(darkMode: false, confirmDeletion: true));
  ValueListenable<Settings> get settings => _settings;

  late Box<Task> _tasks;
  Box<Task> get tasksBox => _tasks;

  final _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    Hive.registerAdapter(TaskAdapter());
    _tasks = await Hive.openBox<Task>('tasks');

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidSettings, iOS: DarwinInitializationSettings());
    await _plugin.initialize(initSettings);

    for (final task in _tasks.values) {
      if (task.notificationId != null && (task.done || task.dueAt == null || task.dueAt!.isBefore(DateTime.now()))) {
        _plugin.cancel(task.notificationId!);
        task.notificationId = null;
        task.save();
      }
    }
  }

  Future<void> add(Task task) async {
    await _tasks.add(task);
    await _scheduleIfNeeded(task);
  }

  Future<void> update(Task task) async {
    await task.save();
    if (task.notificationId != null) {
      await _plugin.cancel(task.notificationId!);
      task.notificationId = null;
    }
    await _scheduleIfNeeded(task);
  }

  Future<void> delete(Task task) async {
    if (task.notificationId != null) {
      await _plugin.cancel(task.notificationId!);
    }
    await task.delete();
  }

  Future<void> toggleDone(Task task) async {
    task.done = !task.done;
    await update(task);
  }

  Future<void> _scheduleIfNeeded(Task task) async {
    if (task.dueAt != null && !task.done) {
      task.notificationId ??= task.key.hashCode ^ task.title.hashCode ^ task.createdAt.millisecondsSinceEpoch;
      final details = const NotificationDetails(
        android: AndroidNotificationDetails(
          'due_channel', 'Task Due',
          channelDescription: 'Reminders for due tasks',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      );
      await _plugin.zonedSchedule(
        task.notificationId!,
        'Task due: ${task.title}',
        task.project != null ? 'Project: ${task.project}' : null,
        tz.TZDateTime.from(task.dueAt!, tz.local),
        details,
        androidAllowWhileIdle: true,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: 'task:${task.key}',
      );
      await task.save();
    }
  }

  void setDarkMode(bool value) => _settings.value = _settings.value.copyWith(darkMode: value);
  void setConfirmDeletion(bool value) => _settings.value = _settings.value.copyWith(confirmDeletion: value);

  String exportJson() {
    final data = _tasks.values.map((t) => {
      'title': t.title,
      'note': t.note,
      'createdAt': t.createdAt.toIso8601String(),
      'dueAt': t.dueAt?.toIso8601String(),
      'done': t.done,
      'project': t.project,
      'tags': t.tags,
      'priority': t.priority,
    }).toList();
    return const JsonEncoder.withIndent('  ').convert({'tasks': data});
  }

  Future<void> importJson(String jsonStr) async {
    final decoded = json.decode(jsonStr) as Map<String, dynamic>;
    final list = (decoded['tasks'] as List).cast<Map<String, dynamic>>();
    for (final m in list) {
      await add(Task(
        title: m['title'] as String,
        note: m['note'] as String?,
        createdAt: DateTime.tryParse(m['createdAt'] ?? '') ?? DateTime.now(),
        dueAt: m['dueAt'] != null ? DateTime.parse(m['dueAt']) : null,
        done: m['done'] ?? false,
        project: m['project'] as String?,
        tags: (m['tags'] as List?)?.cast<String>(),
        priority: (m['priority'] ?? 1) as int,
      ));
    }
  }
}

class tz {
  static final local = _LocalLocation();
  static TZDateTime from(DateTime dt, _LocalLocation _) => TZDateTime(dt);
}

class _LocalLocation {}

class TZDateTime {
  final DateTime dt;
  TZDateTime(this.dt);
  static TZDateTime from(DateTime dt, _LocalLocation _) => TZDateTime(dt);
}