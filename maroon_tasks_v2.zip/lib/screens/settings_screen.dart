import 'package:flutter/material.dart';
import '../data/task_store.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ValueListenableBuilder(
        valueListenable: TaskStore.instance.settings,
        builder: (context, Settings settings, _) {
          return ListView(
            children: [
              SwitchListTile(
                title: const Text('Dark mode (maroon)'),
                value: settings.darkMode,
                onChanged: (v) => TaskStore.instance.setDarkMode(v),
              ),
              SwitchListTile(
                title: const Text('Confirm before deleting'),
                value: settings.confirmDeletion,
                onChanged: (v) => TaskStore.instance.setConfirmDeletion(v),
              ),
              ListTile(
                title: const Text('Export backup (JSON)'),
                leading: const Icon(Icons.upload_file),
                onTap: () async {
                  final json = TaskStore.instance.exportJson();
                  await showDialog(context: context, builder: (_) => _BigText(json: json));
                },
              ),
              ListTile(
                title: const Text('Import backup (JSON)'),
                leading: const Icon(Icons.download),
                onTap: () async {
                  final controller = TextEditingController();
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('Paste JSON'),
                      content: TextField(controller: controller, maxLines: 8),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Import')),
                      ],
                    ),
                  ) ?? false;
                  if (ok) {
                    await TaskStore.instance.importJson(controller.text);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Imported')));
                    }
                  }
                },
              ),
              const SizedBox(height: 12),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text('Tip: Swipe right to complete, left to delete.',
                    style: TextStyle(fontStyle: FontStyle.italic)),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _BigText extends StatelessWidget {
  final String json;
  const _BigText({required this.json});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Exported JSON'),
      content: SingleChildScrollView(child: SelectableText(json)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
      ],
    );
  }
}