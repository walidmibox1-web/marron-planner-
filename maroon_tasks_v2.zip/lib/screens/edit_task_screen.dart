import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/task.dart';
import '../data/task_store.dart';

class EditTaskScreen extends StatefulWidget {
  final Task? task;
  const EditTaskScreen({super.key, this.task});

  @override
  State<EditTaskScreen> createState() => _EditTaskScreenState();
}

class _EditTaskScreenState extends State<EditTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _title;
  late TextEditingController _note;
  late TextEditingController _project;
  late TextEditingController _tags;
  int _priority = 1;
  DateTime? _dueAt;

  @override
  void initState() {
    super.initState();
    final t = widget.task;
    _title = TextEditingController(text: t?.title ?? '');
    _note = TextEditingController(text: t?.note ?? '');
    _project = TextEditingController(text: t?.project ?? '');
    _tags = TextEditingController(text: (t?.tags ?? []).join(', '));
    _priority = t?.priority ?? 1;
    _dueAt = t?.dueAt;
  }

  @override
  void dispose() {
    _title.dispose();
    _note.dispose();
    _project.dispose();
    _tags.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.task == null ? 'New Task' : 'Edit Task'),
        actions: [
          if (widget.task != null)
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Delete task?'),
                    content: const Text('This cannot be undone.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                      FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
                    ],
                  ),
                ) ?? false;
                if (ok) {
                  await TaskStore.instance.delete(widget.task!);
                  if (mounted) Navigator.pop(context);
                }
              },
            ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _save,
          )
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _title,
              decoration: const InputDecoration(labelText: 'Title'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Title is required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _note,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Notes'),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _project,
                    decoration: const InputDecoration(labelText: 'Project'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: DropdownButtonFormField<int>(
                    value: _priority,
                    decoration: const InputDecoration(labelText: 'Priority'),
                    items: const [
                      DropdownMenuItem(value: 0, child: Text('Low')),
                      DropdownMenuItem(value: 1, child: Text('Normal')),
                      DropdownMenuItem(value: 2, child: Text('High')),
                    ],
                    onChanged: (v) => setState(() => _priority = v ?? 1),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _tags,
              decoration: const InputDecoration(labelText: 'Tags (comma-separated)'),
            ),
            const SizedBox(height: 12),
            _DuePicker(
              dueAt: _dueAt,
              onPicked: (d) => setState(() => _dueAt = d),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(onPressed: _save, icon: const Icon(Icons.check), label: const Text('Save')),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final tags = _tags.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
    if (widget.task == null) {
      await TaskStore.instance.add(Task(
        title: _title.text.trim(),
        note: _note.text.trim().isEmpty ? null : _note.text.trim(),
        dueAt: _dueAt,
        project: _project.text.trim().isEmpty ? null : _project.text.trim(),
        tags: tags,
        priority: _priority,
      ));
    } else {
      final t = widget.task!;
      t.title = _title.text.trim();
      t.note = _note.text.trim().isEmpty ? null : _note.text.trim();
      t.project = _project.text.trim().isEmpty ? null : _project.text.trim();
      t.tags = tags;
      t.priority = _priority;
      t.dueAt = _dueAt;
      await TaskStore.instance.update(t);
    }
    if (mounted) Navigator.pop(context);
  }
}

class _DuePicker extends StatelessWidget {
  final DateTime? dueAt;
  final ValueChanged<DateTime?> onPicked;
  const _DuePicker({required this.dueAt, required this.onPicked});

  @override
  Widget build(BuildContext context) {
    final df = DateFormat.yMMMd().add_jm();
    return Row(
      children: [
        Expanded(
          child: InputDecorator(
            decoration: const InputDecoration(labelText: 'Due'),
            child: Text(dueAt == null ? 'None' : df.format(dueAt!)),
          ),
        ),
        const SizedBox(width: 12),
        IconButton(
          icon: const Icon(Icons.event),
          onPressed: () async {
            final now = DateTime.now();
            final date = await showDatePicker(
              context: context,
              firstDate: DateTime(now.year - 1),
              lastDate: DateTime(now.year + 5),
              initialDate: dueAt ?? now,
            );
            if (date == null) return;
            final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(dueAt ?? now));
            if (time == null) return;
            final dt = DateTime(date.year, date.month, date.day, time.hour, time.minute);
            onPicked(dt);
          },
        ),
        if (dueAt != null)
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: () => onPicked(null),
          ),
      ],
    );
  }
}