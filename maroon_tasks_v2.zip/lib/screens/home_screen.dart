import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../data/task_store.dart';
import '../models/task.dart';
import '../widgets/task_tile.dart';
import 'edit_task_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _query = '';
  int _sort = 0;
  String? _projectFilter;
  String? _tagFilter;

  @override
  Widget build(BuildContext context) {
    final box = TaskStore.instance.tasksBox;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Maroon Tasks'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search tasks…',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
              onChanged: (v) => setState(() => _query = v.trim()),
            ),
          ),
        ),
      ),
      body: ValueListenableBuilder(
        valueListenable: box.listenable(),
        builder: (context, Box<Task> box, _) {
          final tasks = box.values.toList();
          final projects = {for (final t in tasks) if (t.project != null) t.project!};
          final tags = {for (final t in tasks) ...t.tags};

          var filtered = tasks.where((t) {
            final q = _query.toLowerCase();
            final match = t.title.toLowerCase().contains(q) || (t.note ?? '').toLowerCase().contains(q);
            final projectOk = _projectFilter == null || t.project == _projectFilter;
            final tagOk = _tagFilter == null || t.tags.contains(_tagFilter);
            return match && projectOk && tagOk;
          }).toList();

          int cmp(Task a, Task b) {
            int c = 0;
            if (_sort == 0) {
              final ad = a.dueAt ?? DateTime(9999);
              final bd = b.dueAt ?? DateTime(9999);
              c = ad.compareTo(bd);
            } else if (_sort == 1) {
              c = b.priority.compareTo(a.priority);
            } else {
              c = b.createdAt.compareTo(a.createdAt);
            }
            if (c == 0) c = a.title.compareTo(b.title);
            return c;
          }
          filtered.sort(cmp);

          return Column(
            children: [
              _FiltersRow(
                projects: projects.toList()..sort(),
                tags: tags.toList()..sort(),
                projectFilter: _projectFilter,
                tagFilter: _tagFilter,
                sort: _sort,
                onClear: () => setState(() { _projectFilter = null; _tagFilter = null; _sort = 0; }),
                onProject: (p) => setState(() => _projectFilter = p),
                onTag: (t) => setState(() => _tagFilter = t),
                onSort: (s) => setState(() => _sort = s),
              ),
              Expanded(
                child: ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final task = filtered[i];
                    return Dismissible(
                      key: ValueKey(task.key),
                      background: Container(
                        color: Colors.green,
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.only(left: 16),
                        child: const Icon(Icons.check, color: Colors.white),
                      ),
                      secondaryBackground: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 16),
                        child: const Icon(Icons.delete, color: Colors.white),
                      ),
                      confirmDismiss: (dir) async {
                        if (dir == DismissDirection.endToStart) {
                          final confirm = !TaskStore.instance.settings.value.confirmDeletion ? true :
                            await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('Delete task?'),
                                content: Text('\"${task.title}\" will be removed.'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                  FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
                                ],
                              ),
                            ) ?? false;
                          if (confirm) await TaskStore.instance.delete(task);
                          return confirm;
                        } else {
                          await TaskStore.instance.toggleDone(task);
                          return false;
                        }
                      },
                      child: TaskTile(
                        task: task,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => EditTaskScreen(task: task),
                        )),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => const EditTaskScreen(),
        )),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _FiltersRow extends StatelessWidget {
  final List<String> projects;
  final List<String> tags;
  final String? projectFilter;
  final String? tagFilter;
  final int sort;
  final VoidCallback onClear;
  final ValueChanged<String?> onProject;
  final ValueChanged<String?> onTag;
  final ValueChanged<int> onSort;

  const _FiltersRow({
    required this.projects,
    required this.tags,
    required this.projectFilter,
    required this.tagFilter,
    required this.sort,
    required this.onClear,
    required this.onProject,
    required this.onTag,
    required this.onSort,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          DropdownButton<String?>(
            hint: const Text('Project'),
            value: projectFilter,
            items: [const DropdownMenuItem(value: null, child: Text('All projects')),
              ...projects.map((p) => DropdownMenuItem(value: p, child: Text(p)))],
            onChanged: onProject,
          ),
          DropdownButton<String?>(
            hint: const Text('Tag'),
            value: tagFilter,
            items: [const DropdownMenuItem(value: null, child: Text('All tags')),
              ...tags.map((t) => DropdownMenuItem(value: t, child: Text(t)))],
            onChanged: onTag,
          ),
          DropdownButton<int>(
            value: sort,
            items: const [
              DropdownMenuItem(value: 0, child: Text('Sort: Due date')),
              DropdownMenuItem(value: 1, child: Text('Sort: Priority')),
              DropdownMenuItem(value: 2, child: Text('Sort: Newest')),
            ],
            onChanged: onSort,
          ),
          TextButton.icon(onPressed: onClear, icon: const Icon(Icons.clear), label: const Text('Clear')),
        ],
      ),
    );
  }
}