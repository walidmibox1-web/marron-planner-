import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart' as pp;

import 'models/task.dart';
import 'data/task_store.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final appDir = await pp.getApplicationDocumentsDirectory();
  await Hive.initFlutter(appDir.path);
  Hive.registerAdapter(TaskAdapter());
  await TaskStore.instance.init();
  runApp(const MaroonTasksApp());
}

class MaroonTasksApp extends StatefulWidget {
  const MaroonTasksApp({super.key});
  @override
  State<MaroonTasksApp> createState() => _MaroonTasksAppState();
}

class _MaroonTasksAppState extends State<MaroonTasksApp> {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: TaskStore.instance.settings,
      builder: (context, Settings settings, _) {
        final theme = _buildTheme(settings.darkMode);
        return MaterialApp(
          title: 'Maroon Tasks',
          debugShowCheckedModeBanner: false,
          theme: theme.light,
          darkTheme: theme.dark,
          themeMode: settings.darkMode ? ThemeMode.dark : ThemeMode.light,
          home: const HomeScreen(),
        );
      },
    );
  }
}

class _DualTheme {
  final ThemeData light;
  final ThemeData dark;
  _DualTheme(this.light, this.dark);
}

_DualTheme _buildTheme(bool dark) {
  const maroon = Color(0xFF5B0A0A);
  const maroonDark = Color(0xFF3E0707);
  const accent = Color(0xFFE6D1D1);
  final baseLight = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: ColorScheme.fromSeed(seedColor: maroon, brightness: Brightness.light)
        .copyWith(primary: maroon, secondary: maroon, surface: Colors.white),
    scaffoldBackgroundColor: Colors.white,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.white,
      foregroundColor: maroon,
      elevation: 0,
    ),
    chipTheme: const ChipThemeData(
      backgroundColor: accent,
      labelStyle: TextStyle(color: maroon),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: maroon,
      foregroundColor: Colors.white,
    ),
  );

  final baseDark = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: ColorScheme.fromSeed(seedColor: maroonDark, brightness: Brightness.dark)
        .copyWith(primary: maroon, secondary: maroonDark, surface: maroonDark),
    scaffoldBackgroundColor: const Color(0xFF121212),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF121212),
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    chipTheme: const ChipThemeData(
      backgroundColor: Color(0xFF2A1A1A),
      labelStyle: TextStyle(color: Colors.white),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: maroon,
      foregroundColor: Colors.white,
    ),
  );

  return _DualTheme(baseLight, baseDark);
}