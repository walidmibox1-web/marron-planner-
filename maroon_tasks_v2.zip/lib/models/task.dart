import 'package:hive/hive.dart';

part 'task.g.dart';

@HiveType(typeId: 1)
class Task extends HiveObject {
  @HiveField(0)
  String title;

  @HiveField(1)
  String? note;

  @HiveField(2)
  DateTime createdAt;

  @HiveField(3)
  DateTime? dueAt;

  @HiveField(4)
  bool done;

  @HiveField(5)
  String? project;

  @HiveField(6)
  List<String> tags;

  @HiveField(7)
  int priority;

  @HiveField(8)
  int? notificationId;

  Task({
    required this.title,
    this.note,
    DateTime? createdAt,
    this.dueAt,
    this.done = false,
    this.project,
    List<String>? tags,
    this.priority = 1,
    this.notificationId,
  })  : createdAt = createdAt ?? DateTime.now(),
        tags = tags ?? [];
}