// GENERATED MANUALLY: Simple Hive adapter without build_runner
part of 'task.dart';

class TaskAdapter extends TypeAdapter<Task> {
  @override
  final int typeId = 1;

  @override
  Task read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{};
    for (int i = 0; i < numOfFields; i++) {
      fields[reader.readByte()] = reader.read();
    }
    return Task(
      title: fields[0] as String,
      note: fields[1] as String?,
      createdAt: fields[2] as DateTime?,
      dueAt: fields[3] as DateTime?,
      done: fields[4] as bool? ?? false,
      project: fields[5] as String?,
      tags: (fields[6] as List?)?.cast<String>(),
      priority: fields[7] as int? ?? 1,
    )..notificationId = fields[8] as int?;
  }

  @override
  void write(BinaryWriter writer, Task obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.title)
      ..writeByte(1)
      ..write(obj.note)
      ..writeByte(2)
      ..write(obj.createdAt)
      ..writeByte(3)
      ..write(obj.dueAt)
      ..writeByte(4)
      ..write(obj.done)
      ..writeByte(5)
      ..write(obj.project)
      ..writeByte(6)
      ..write(obj.tags)
      ..writeByte(7)
      ..write(obj.priority)
      ..writeByte(8)
      ..write(obj.notificationId);
  }
}