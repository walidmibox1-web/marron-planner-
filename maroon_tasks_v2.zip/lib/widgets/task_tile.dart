import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/task.dart';

class TaskTile extends StatelessWidget {
  final Task task;
  final VoidCallback? onTap;
  const TaskTile({super.key, required this.task, this.onTap});

  @override
  Widget build(BuildContext context) {
    final df = DateFormat.MMMd().add_jm();
    final due = task.dueAt != null ? df.format(task.dueAt!) : null;
    final priorityIcon = [Icons.arrow_downward, Icons.horizontal_rule, Icons.arrow_upward][task.priority.clamp(0, 2)];
    final priorityColor = [Colors.green, Colors.amber, Colors.red][task.priority.clamp(0, 2)];

    return ListTile(
      onTap: onTap,
      leading: Icon(
        task.done ? Icons.check_circle : Icons.radio_button_unchecked,
        color: task.done ? Colors.green : Theme.of(context).colorScheme.primary,
      ),
      title: Text(
        task.title,
        style: TextStyle(decoration: task.done ? TextDecoration.lineThrough : null),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (task.note != null && task.note!.isNotEmpty)
            Text(task.note!, maxLines: 1, overflow: TextOverflow.ellipsis),
          Wrap(
            spacing: 6,
            runSpacing: -6,
            children: [
              if (task.project != null) Chip(label: Text(task.project!)),
              for (final t in task.tags) Chip(label: Text(t)),
              if (due != null) Chip(label: Text('Due: $due')),
            ],
          ),
        ],
      ),
      trailing: Icon(priorityIcon, color: priorityColor),
    );
  }
}